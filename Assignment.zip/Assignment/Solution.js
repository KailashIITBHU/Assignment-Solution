const fs = require('fs');

function calculateBalanceSheet(data) {
  const {  revenueData, expenseData } = data;

  const balancesheet = {};

  // Iterate over revenue entries and calculate the balance for each month
  revenueData.forEach(revenueEntry => {
    const { startDate, amount } = revenueEntry;
    const date= startDate;
    balancesheet[date] = (balancesheet[date] || 0) + amount;
  });

  // Iterate over expense entries and subtract the expense amount for each month
  expenseData.forEach(expenseEntry => {
    const { startDate, amount } = expenseEntry;
    const date = startDate;
    balancesheet[date] = (balancesheet[date] || 0) - amount;
  });

  // Sort the balancesheet by timestamp in ascending order
  const sortedBalancesheet = Object.entries(balancesheet).sort((a, b) => {
    const dateA = new Date(a[0]);
    const dateB = new Date(b[0]);
    return dateA - dateB;
  });

  return sortedBalancesheet;
}

function getMonth(timestamp) {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  return `${year}-${month.toString().padStart(2, '0')}`;
}

// Read the input JSON file
fs.readFile('./2-input.json', 'utf8', (err, jsonString) => {
  if (err) {
    console.log('Error reading file:', err);
    return;
  }

  try {
    const data = JSON.parse(jsonString);
    const balancesheet = calculateBalanceSheet(data);

    // Output the result to the console
    let Balance=[];
    balancesheet.forEach(([date, balance]) => {
        let obj={
            amount:balance,
            startDate:date
        }
        Balance.push(obj);
        
      
    });
    console.log(Balance);
  } catch (error) {
    console.log('Error parsing JSON:', error);
  }
});
